#include <stdio.h>
#include <stdlib.h>

// Structure pour représenter un élève
typedef struct Eleve {
    int rang;
    float note;
    struct Eleve* suivant;
} Eleve;

// Fonction pour créer un nouvel élève
Eleve* creerEleve(int rang, float note) {
    Eleve* nouvelEleve = (Eleve*)malloc(sizeof(Eleve));
    nouvelEleve->rang = rang;
    nouvelEleve->note = note;
    nouvelEleve->suivant = NULL;
    return nouvelEleve;
}

// Fonction pour ajouter un élève à la fin de la liste
void ajouterEleve(Eleve** tete, int rang, float note) {
    Eleve* nouvelEleve = creerEleve(rang, note);
    if (*tete == NULL) {
        *tete = nouvelEleve;
    } else {
        Eleve* temp = *tete;
        while (temp->suivant != NULL) {
            temp = temp->suivant;
        }
        temp->suivant = nouvelEleve;
    }
}

// Fonction pour afficher la liste des élèves
void afficherListe(Eleve* tete) {
    while (tete != NULL) {
        printf("Rang: %d, Note: %.2f\n", tete->rang, tete->note);
        tete = tete->suivant;
    }
}

// Fonction pour effectuer le tri à bulles
void triBulles(Eleve* tete) {
    if (!tete) return;
    int echange;
    Eleve *temp, *dernier = NULL;

    do {
        echange = 0;
        temp = tete;

        while (temp->suivant != dernier) {
            if (temp->note < temp->suivant->note) {
                // Échanger les notes et les rangs
                int tempRang = temp->rang;
                float tempNote = temp->note;
                temp->rang = temp->suivant->rang;
                temp->note = temp->suivant->note;
                temp->suivant->rang = tempRang;
                temp->suivant->note = tempNote;
                echange = 1;
            }
            temp = temp->suivant;
        }
        dernier = temp;
    } while (echange);
}

// Fonction pour libérer la mémoire de la liste
void libererListe(Eleve* tete) {
    Eleve* temp;
    while (tete != NULL) {
        temp = tete;
        tete = tete->suivant;
        free(temp);
    }
}

int main() {
    Eleve* liste = NULL;
    int n, rang;
    float note;

    printf("Combien d'eleves voulez-vous entrer? ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Entrez le rang et la note de l'eleve %d: \n", i + 1);
        printf("Rang: ");
        scanf("%d", &rang);
        printf("Note: ");
        scanf("%f", &note);
        ajouterEleve(&liste, rang, note);
    }

    printf("Liste avant le tri :\n");
    afficherListe(liste);

    // Trier la liste
    triBulles(liste);

    printf("\nListe apres le tri :\n");
    afficherListe(liste);

    // Libérer la mémoire
    libererListe(liste);

    return 0;
}
