#include <stdio.h>
#include <stdlib.h>

typedef struct Demande {
    int position;
    struct Demande* suivant;
} Demande;

Demande* creerDemande(int position) {
    Demande* nouvelleDemande = (Demande*)malloc(sizeof(Demande));
    nouvelleDemande->position = position;
    nouvelleDemande->suivant = NULL;
    return nouvelleDemande;
}

void ajouterDemande(Demande** tete, int position) {
    Demande* nouvelleDemande = creerDemande(position);
    if (*tete == NULL) {
        *tete = nouvelleDemande;
    } else {
        Demande* temp = *tete;
        while (temp->suivant != NULL) temp = temp->suivant;
        temp->suivant = nouvelleDemande;
    }
}

void traiterDemandesFCFS(Demande* tete) {
    int positionActuelle = 0;
    int numeroDemande = 1;
    while (tete != NULL) {
        printf("demande %d: Acces vers la position %d (deplacement de %d vers %d, donc deplacement de %d).\n",
               numeroDemande, tete->position, positionActuelle, tete->position, abs(tete->position - positionActuelle));
        positionActuelle = tete->position;
        tete = tete->suivant;
        numeroDemande++;
    }
}

void libererListe(Demande* tete) {
    while (tete != NULL) {
        Demande* temp = tete;
        tete = tete->suivant;
        free(temp);
    }
}

int main() {
    Demande* liste = NULL;
    int n, position;

    printf("Combien de demandes d'acces voulez-vous entrer? ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Entrez la position de la demande d'acces: ", i + 1);
        scanf("%d", &position);
        ajouterDemande(&liste, position);
    }

    traiterDemandesFCFS(liste);
    libererListe(liste);

    return 0;
}
