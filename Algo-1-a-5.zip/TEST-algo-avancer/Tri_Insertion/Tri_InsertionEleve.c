#include <stdio.h>
#include <stdlib.h>

// Structure pour repr�senter un �l�ve
typedef struct Eleve {
    int rang;
    float note;
    struct Eleve* suivant;
} Eleve;

// Fonction pour cr�er un nouvel �l�ve
Eleve* creerEleve(int rang, float note) {
    Eleve* nouvelEleve = (Eleve*)malloc(sizeof(Eleve));
    nouvelEleve->rang = rang;
    nouvelEleve->note = note;
    nouvelEleve->suivant = NULL;
    return nouvelEleve;
}

// Fonction pour ajouter un �l�ve � la fin de la liste
void ajouterEleve(Eleve** tete, int rang, float note) {
    Eleve* nouvelEleve = creerEleve(rang, note);
    if (*tete == NULL) {
        *tete = nouvelEleve;
    } else {
        Eleve* temp = *tete;
        while (temp->suivant != NULL) {
            temp = temp->suivant;
        }
        temp->suivant = nouvelEleve;
    }
}

// Fonction pour afficher la liste des �l�ves
void afficherListe(Eleve* tete) {
    while (tete != NULL) {
        printf("Rang: %d, Note: %.2f\n", tete->rang, tete->note);
        tete = tete->suivant;
    }
}

// Fonction pour trier la liste par insertion
void triParInsertion(Eleve** tete) {
    if (*tete == NULL || (*tete)->suivant == NULL) return;

    Eleve* sorted = NULL;  // Liste tri�e
    Eleve* current = *tete;

    while (current != NULL) {
        Eleve* suivant = current->suivant;  // Stocke le suivant
        // Ins�re current dans la liste tri�e
        if (sorted == NULL || sorted->note <= current->note) {
            current->suivant = sorted;
            sorted = current;
        } else {
            Eleve* temp = sorted;
            while (temp->suivant != NULL && temp->suivant->note > current->note) {
                temp = temp->suivant;
            }
            current->suivant = temp->suivant;
            temp->suivant = current;
        }
        current = suivant;
    }

    *tete = sorted;
}

// Fonction pour lib�rer la m�moire de la liste
void libererListe(Eleve* tete) {
    Eleve* temp;
    while (tete != NULL) {
        temp = tete;
        tete = tete->suivant;
        free(temp);
    }
}

int main() {
    Eleve* liste = NULL;
    int n, rang;
    float note;

    printf("Combien d'eleves voulez-vous entrer? ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Entrez le rang et la note de l'eleve %d: \n", i + 1);
        printf("Rang: ");
        scanf("%d", &rang);
        printf("Note: ");
        scanf("%f", &note);
        ajouterEleve(&liste, rang, note);
    }

    printf("Liste avant le tri :\n");
    afficherListe(liste);

    // Trier la liste
    triParInsertion(&liste);

    printf("\nListe apr�s le tri :\n");
    afficherListe(liste);

    // Lib�rer la m�moire
    libererListe(liste);

    return 0;
}
